from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, literal, String
from datetime import datetime, timedelta, time as dt_time
from typing import List, Optional, Tuple
from fastapi import HTTPException, status

from database.models import (
    Appointment, Provider, ProviderAvailability, ProviderUnavailability,
    ExaminationRoom, MedicalEquipment, AppointmentEquipment, ServiceType,
    Clinic, Patient, User, Notification, AuditLog, Schedule,
    AppointmentStatus, AppointmentPriority, UserRole, AuditAction
)
from schemas.schema import AppointmentCreate, AvailableSlot


class AppointmentService:
    """Business logic for appointment management"""

    @staticmethod
    def check_provider_availability(
            db: Session,
            provider_id: int,
            appointment_datetime: datetime,
            duration_minutes: int,
            exclude_appointment_id: Optional[int] = None
    ) -> bool:
        """Check if provider is available at the specified time"""
        end_datetime = appointment_datetime + timedelta(minutes=duration_minutes)
        day_of_week = appointment_datetime.weekday()
        appointment_time = appointment_datetime.time()

        # 1. Check Schedule
        availability = db.query(ProviderAvailability).filter(
            and_(
                ProviderAvailability.provider_id == provider_id,
                ProviderAvailability.day_of_week == day_of_week,
                ProviderAvailability.is_available == True
            )
        ).first()

        if not availability:
            return False

        if not (availability.start_time <= appointment_time <= availability.end_time):
            return False

        # 2. Check Unavailability (Time off)
        unavailable = db.query(ProviderUnavailability).filter(
            and_(
                ProviderUnavailability.provider_id == provider_id,
                or_(
                    and_(ProviderUnavailability.start_datetime <= appointment_datetime,
                         ProviderUnavailability.end_datetime > appointment_datetime),
                    and_(ProviderUnavailability.start_datetime < end_datetime,
                         ProviderUnavailability.end_datetime >= end_datetime)
                )
            )
        ).first()

        if unavailable:
            return False

        # 3. Check Double Booking (PostgreSQL Compatible)
        # Logic: Start < Existing_End AND End > Existing_Start
        # Existing_End = appointment_datetime + duration_minutes

        query = db.query(Appointment).filter(
            and_(
                Appointment.provider_id == provider_id,
                Appointment.status.in_([
                    AppointmentStatus.REQUESTED,
                    AppointmentStatus.CONFIRMED,
                    AppointmentStatus.CHECKED_IN
                ]),
                # New Start < Existing End (Existing Start + Duration)
                Appointment.appointment_datetime < end_datetime,
                # Existing Start < New End
                (Appointment.appointment_datetime + func.make_interval(0, 0, 0, 0, 0,
                                                                       Appointment.duration_minutes)) > appointment_datetime
            )
        )

        if exclude_appointment_id:
            query = query.filter(Appointment.id != exclude_appointment_id)

        return query.first() is None

    @staticmethod
    def check_room_availability(
            db: Session,
            room_id: int,
            appointment_datetime: datetime,
            duration_minutes: int,
            exclude_appointment_id: Optional[int] = None
    ) -> bool:
        end_datetime = appointment_datetime + timedelta(minutes=duration_minutes)

        # PostgreSQL Compatible
        query = db.query(Appointment).filter(
            and_(
                Appointment.examination_room_id == room_id,
                Appointment.status.in_(
                    [AppointmentStatus.REQUESTED, AppointmentStatus.CONFIRMED, AppointmentStatus.CHECKED_IN]),
                Appointment.appointment_datetime < end_datetime,
                (Appointment.appointment_datetime + func.make_interval(0, 0, 0, 0, 0,
                                                                       Appointment.duration_minutes)) > appointment_datetime
            )
        )
        if exclude_appointment_id:
            query = query.filter(Appointment.id != exclude_appointment_id)
        return query.first() is None

    @staticmethod
    def check_equipment_availability(
            db: Session,
            equipment_id: int,
            appointment_datetime: datetime,
            duration_minutes: int,
            exclude_appointment_id: Optional[int] = None
    ) -> bool:
        end_datetime = appointment_datetime + timedelta(minutes=duration_minutes)

        # PostgreSQL Compatible
        query = db.query(Appointment).join(AppointmentEquipment).filter(
            and_(
                AppointmentEquipment.equipment_id == equipment_id,
                Appointment.status.in_(
                    [AppointmentStatus.REQUESTED, AppointmentStatus.CONFIRMED, AppointmentStatus.CHECKED_IN]),
                Appointment.appointment_datetime < end_datetime,
                (Appointment.appointment_datetime + func.make_interval(0, 0, 0, 0, 0,
                                                                       Appointment.duration_minutes)) > appointment_datetime
            )
        )
        if exclude_appointment_id:
            query = query.filter(Appointment.id != exclude_appointment_id)
        return query.first() is None
    @staticmethod
    def is_after_hours(db: Session, clinic_id: int, appointment_datetime: datetime) -> bool:
        clinic = db.query(Clinic).filter(Clinic.id == clinic_id).first()
        if not clinic or not clinic.operating_hours_start or not clinic.operating_hours_end:
            return False  # Assume open if no hours set
        t = appointment_datetime.time()
        return not (clinic.operating_hours_start <= t <= clinic.operating_hours_end)

    @staticmethod
    def auto_assign_provider(db: Session, clinic_id: int, service_type_id: int, appointment_datetime: datetime,
                             duration_minutes: int) -> Optional[int]:
        # 1. Get providers with matching specialty for the service (Simplified: All providers in clinic)
        providers = db.query(Provider).filter(Provider.clinic_id == clinic_id, Provider.is_active == True).all()

        for p in providers:
            if AppointmentService.check_provider_availability(db, p.id, appointment_datetime, duration_minutes):
                return p.id
        return None

    @staticmethod
    def allocate_resources(db: Session, appointment: Appointment):
        # 1. Allocate Room
        if not appointment.examination_room_id:
            rooms = db.query(ExaminationRoom).filter(
                ExaminationRoom.clinic_id == appointment.clinic_id,
                ExaminationRoom.is_active == True
            ).all()

            for room in rooms:
                if AppointmentService.check_room_availability(db, room.id, appointment.appointment_datetime,
                                                              appointment.duration_minutes,
                                                              exclude_appointment_id=appointment.id):
                    appointment.examination_room_id = room.id
                    break

        # 2. Allocate Equipment
        service = db.query(ServiceType).filter(ServiceType.id == appointment.service_type_id).first()
        if service and service.requires_equipment:
            existing = db.query(AppointmentEquipment).filter(
                AppointmentEquipment.appointment_id == appointment.id).first()
            if not existing:
                equipments = db.query(MedicalEquipment).filter(MedicalEquipment.is_active == True).all()
                for eq in equipments:
                    if AppointmentService.check_equipment_availability(db, eq.id, appointment.appointment_datetime,
                                                                       appointment.duration_minutes,
                                                                       exclude_appointment_id=appointment.id):
                        assign = AppointmentEquipment(appointment_id=appointment.id, equipment_id=eq.id)
                        db.add(assign)
                        break

    @staticmethod
    def get_available_slots(db: Session, clinic_id: int, service_type_id: int, start_date: datetime, end_date: datetime,
                            slot_duration_minutes: int = 30) -> List[AvailableSlot]:
        available_slots = []
        current_date = start_date.date()
        end = end_date.date()

        while current_date <= end:
            day_of_week = current_date.weekday()
            # Get providers working this day
            availabilities = db.query(ProviderAvailability).join(Provider).filter(
                and_(
                    Provider.clinic_id == clinic_id,
                    Provider.is_active == True,
                    ProviderAvailability.day_of_week == day_of_week,
                    ProviderAvailability.is_available == True
                )
            ).all()

            for av in availabilities:
                current_time = datetime.combine(current_date, av.start_time)
                end_time_sched = datetime.combine(current_date, av.end_time)

                while current_time + timedelta(minutes=slot_duration_minutes) <= end_time_sched:
                    if AppointmentService.check_provider_availability(db, av.provider_id, current_time,
                                                                      slot_duration_minutes):
                        user = db.query(User).filter(User.id == av.provider.user_id).first()
                        available_slots.append(AvailableSlot(
                            provider_id=av.provider_id,
                            provider_name=user.full_name if user else "Unknown",
                            start_time=current_time,
                            end_time=current_time + timedelta(minutes=slot_duration_minutes)
                        ))
                    current_time += timedelta(minutes=slot_duration_minutes)
            current_date += timedelta(days=1)
        return available_slots

    @staticmethod
    def create_notification(db: Session, patient_id: int, appointment_id: int, notification_type: str, message: str):
        notification = Notification(patient_id=patient_id, appointment_id=appointment_id,
                                    notification_type=notification_type, message=message)
        db.add(notification)
        db.commit()

    @staticmethod
    def create_audit_log(db: Session, user_id: int, action: AuditAction, appointment_id: Optional[int] = None,
                         details: Optional[str] = None, ip_address: Optional[str] = None):
        audit_log = AuditLog(user_id=user_id, appointment_id=appointment_id, action=action, details=details,
                             ip_address=ip_address)
        db.add(audit_log)
        db.commit()

    @staticmethod
    def validate_reschedule(appointment: Appointment, new_datetime: datetime) -> bool:
        if new_datetime <= datetime.now():
            raise HTTPException(status_code=400, detail="Time must be in future")
        hours_diff = (appointment.appointment_datetime - datetime.now()).total_seconds() / 3600
        if hours_diff < 24:
            raise HTTPException(status_code=400, detail="Must reschedule 24 hours in advance")
        return True