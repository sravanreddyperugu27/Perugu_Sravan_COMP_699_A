from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from datetime import datetime, date, time
from database.models import UserRole, AppointmentStatus, AppointmentPriority, AuditAction




class PatientRegister(BaseModel):
    user_id: str
    password: str
    email: EmailStr
    full_name: str

class StaffRegister(BaseModel):
    user_id: str
    password: str
    email: EmailStr
    full_name: str
    role: UserRole

# User Schemas
class UserBase(BaseModel):
    email: EmailStr
    full_name: str
    role: UserRole


class UserCreate(UserBase):
    user_id: str
    password: str


class UserResponse(UserBase):
    id: int
    user_id: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UserLogin(BaseModel):
    user_id: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    user_id: Optional[str] = None


# Patient Schemas
class PatientBase(BaseModel):
    phone_number: Optional[str] = None
    date_of_birth: Optional[date] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None


class PatientCreate(PatientBase):
    user_id: int
    medical_record_number: str


class PatientResponse(PatientBase):
    id: int
    user_id: int
    medical_record_number: str
    created_at: datetime

    class Config:
        from_attributes = True


# Clinic Schemas
class ClinicBase(BaseModel):
    name: str
    address: str
    phone_number: Optional[str] = None
    email: Optional[str] = None
    operating_hours_start: Optional[time] = None
    operating_hours_end: Optional[time] = None


class ClinicCreate(ClinicBase):
    pass


class ClinicResponse(ClinicBase):
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Provider Schemas
class ProviderBase(BaseModel):
    clinic_id: int
    specialty: str
    license_number: Optional[str] = None
    phone_number: Optional[str] = None


class ProviderCreate(ProviderBase):
    user_id: int


class ProviderResponse(ProviderBase):
    id: int
    user_id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Provider Availability Schemas
class ProviderAvailabilityBase(BaseModel):
    day_of_week: int = Field(..., ge=0, le=6)
    start_time: time
    end_time: time


class ProviderAvailabilityCreate(ProviderAvailabilityBase):
    provider_id: int


class ProviderAvailabilityResponse(ProviderAvailabilityBase):
    id: int
    provider_id: int
    is_available: bool
    created_at: datetime

    class Config:
        from_attributes = True


class ProviderUnavailabilityBase(BaseModel):
    start_datetime: datetime
    end_datetime: datetime
    reason: Optional[str] = None


class ProviderUnavailabilityCreate(ProviderUnavailabilityBase):
    provider_id: int


class ProviderUnavailabilityResponse(ProviderUnavailabilityBase):
    id: int
    provider_id: int
    created_at: datetime

    class Config:
        from_attributes = True


# Examination Room Schemas
class ExaminationRoomBase(BaseModel):
    room_number: str
    room_type: Optional[str] = None
    capacity: int = 1


class ExaminationRoomCreate(ExaminationRoomBase):
    clinic_id: int


class ExaminationRoomResponse(ExaminationRoomBase):
    id: int
    clinic_id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Medical Equipment Schemas
class MedicalEquipmentBase(BaseModel):
    name: str
    equipment_type: str
    model_number: Optional[str] = None
    serial_number: Optional[str] = None


class MedicalEquipmentCreate(MedicalEquipmentBase):
    pass


class MedicalEquipmentResponse(MedicalEquipmentBase):
    id: int
    is_available: bool
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Service Type Schemas
class ServiceTypeBase(BaseModel):
    name: str
    description: Optional[str] = None
    duration_minutes: int = 30
    requires_equipment: bool = False
    priority_level: AppointmentPriority = AppointmentPriority.MEDIUM


class ServiceTypeCreate(ServiceTypeBase):
    clinic_id: int


class ServiceTypeResponse(ServiceTypeBase):
    id: int
    clinic_id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Appointment Schemas
class AppointmentBase(BaseModel):
    clinic_id: int
    service_type_id: int
    appointment_datetime: datetime
    notes: Optional[str] = None


class AppointmentCreate(AppointmentBase):
    patient_id: Optional[int] = None  # Optional for admin creating on behalf
    provider_id: Optional[int] = None  # System can auto-assign
    priority: Optional[AppointmentPriority] = AppointmentPriority.MEDIUM


class AppointmentUpdate(BaseModel):
    appointment_datetime: Optional[datetime] = None
    provider_id: Optional[int] = None
    examination_room_id: Optional[int] = None
    status: Optional[AppointmentStatus] = None
    notes: Optional[str] = None


class AppointmentReschedule(BaseModel):
    appointment_datetime: datetime

    @validator('appointment_datetime')
    def validate_reschedule_time(cls, v):
        # Must be at least 24 hours in advance
        if v <= datetime.now():
            raise ValueError('Appointment must be in the future')
        return v


class AppointmentResponse(AppointmentBase):
    id: int
    patient_id: int
    provider_id: int
    examination_room_id: Optional[int]
    duration_minutes: int
    status: AppointmentStatus
    priority: AppointmentPriority
    is_after_hours: bool
    requires_approval: bool
    approved_by: Optional[int]
    created_at: datetime
    updated_at: Optional[datetime]
    checked_in_at: Optional[datetime]
    completed_at: Optional[datetime]
    cancelled_at: Optional[datetime]

    class Config:
        from_attributes = True


class AppointmentDetailResponse(AppointmentResponse):
    patient: Optional[dict] = None
    provider: Optional[dict] = None
    clinic: Optional[dict] = None
    service_type: Optional[dict] = None
    examination_room: Optional[dict] = None
    equipment: Optional[List[dict]] = []


class AvailableSlot(BaseModel):
    provider_id: int
    provider_name: str
    start_time: datetime
    end_time: datetime


class AppointmentEquipmentBase(BaseModel):
    equipment_id: int


class AppointmentEquipmentCreate(AppointmentEquipmentBase):
    appointment_id: int


class AppointmentEquipmentResponse(AppointmentEquipmentBase):
    id: int
    appointment_id: int
    assigned_at: datetime

    class Config:
        from_attributes = True


# Notification Schemas
class NotificationBase(BaseModel):
    message: str
    notification_type: str


class NotificationCreate(NotificationBase):
    patient_id: int
    appointment_id: Optional[int] = None


class NotificationResponse(NotificationBase):
    id: int
    patient_id: int
    appointment_id: Optional[int]
    is_read: bool
    sent_at: datetime

    class Config:
        from_attributes = True


# Audit Log Schemas
class AuditLogBase(BaseModel):
    action: AuditAction
    details: Optional[str] = None


class AuditLogCreate(AuditLogBase):
    user_id: int
    appointment_id: Optional[int] = None
    ip_address: Optional[str] = None


class AuditLogResponse(AuditLogBase):
    id: int
    user_id: int
    appointment_id: Optional[int]
    ip_address: Optional[str]
    timestamp: datetime

    class Config:
        from_attributes = True


# Schedule Schemas
class ScheduleBase(BaseModel):
    clinic_id: int
    schedule_date: date
    notes: Optional[str] = None


class ScheduleCreate(ScheduleBase):
    pass


class ScheduleResponse(ScheduleBase):
    id: int
    generated_by: int
    is_official: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Report Schemas
class AppointmentVolumeReport(BaseModel):
    clinic_id: int
    clinic_name: str
    date: date
    total_appointments: int
    requested: int
    confirmed: int
    completed: int
    cancelled: int
    after_hours: int


class ProviderUtilizationReport(BaseModel):
    provider_id: int
    provider_name: str
    specialty: str
    total_appointments: int
    completed_appointments: int
    cancelled_appointments: int
    utilization_rate: float
    total_scheduled_minutes: int


class WaitTimeReport(BaseModel):
    average_wait_minutes: float
    median_wait_minutes: float
    max_wait_minutes: float
    min_wait_minutes: float
    total_appointments: int


class ResourceUtilizationReport(BaseModel):
    resource_type: str
    resource_name: str
    total_bookings: int
    total_minutes_used: int
    utilization_rate: float


# Conflict Reporting Schemas (Added to fix ImportError)
class ConflictDetail(BaseModel):
    provider_id: Optional[int] = None
    room_id: Optional[int] = None
    equipment_id: Optional[int] = None
    appointment_1: int
    appointment_2: int
    conflict_time: str
    severity: str


class ConflictReport(BaseModel):
    provider_conflicts: List[ConflictDetail]
    room_conflicts: List[ConflictDetail]
    equipment_conflicts: List[ConflictDetail]