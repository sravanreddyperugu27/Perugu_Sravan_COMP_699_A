from fastapi import FastAPI, HTTPException,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from starlette.responses import HTMLResponse
from starlette.templating import Jinja2Templates

from database.db import engine, Base
from router import auth_route as auth_router
from router import patients as patients_router
from router import providers as providers_router
from router import admin as admin_router
from router import managers as managers_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Smart Healthcare Appointment and Resource Management System",
    description="A comprehensive system for managing healthcare appointments, resources, and scheduling",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


templates = Jinja2Templates(directory="templates")
app.include_router(auth_router.router)
app.include_router(patients_router.router)
app.include_router(providers_router.router)
app.include_router(admin_router.router)
app.include_router(managers_router.router)



@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    """
    Serves the Single Page Application (SPA) entry point.
    Jinja2 injects the 'request' context which is required for url_for to work.
    """
    return templates.TemplateResponse("inde.html", {"request": request})

@app.get("/")
def read_root():
    """Root endpoint"""
    return {
        "message": "Smart Healthcare Appointment and Resource Management System",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "operational"
    }


@app.get("/api/v1/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "healthcare-appointment-system"
    }


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Custom HTTP exception handler"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "status_code": exc.status_code
        }
    )


if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )