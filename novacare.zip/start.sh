#!/bin/bash

# Smart Healthcare System - Quick Start Script
# This script sets up and runs the entire application

set -e

echo "=================================================="
echo "Smart Healthcare Appointment Management System"
echo "Quick Start Script"
echo "=================================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    echo "Visit: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✓ Docker is installed"
echo "✓ Docker Compose is installed"
echo ""

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cp .env.example .env

    # Generate a random secret key
    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")

    # Update SECRET_KEY in .env
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/your-secret-key-here-change-in-production/$SECRET_KEY/" .env
    else
        # Linux
        sed -i "s/your-secret-key-here-change-in-production/$SECRET_KEY/" .env
    fi

    echo "✓ .env file created with secure secret key"
else
    echo "✓ .env file already exists"
fi

echo ""
echo "Starting services with Docker Compose..."
echo ""

# Stop any existing containers
docker-compose down 2>/dev/null || true

# Build and start containers
docker-compose up -d --build

echo ""
echo "Waiting for database to be ready..."
sleep 5

# Check if database is ready
echo "Checking database connection..."
until docker-compose exec -T db pg_isready -U postgres > /dev/null 2>&1; do
    echo "Waiting for database..."
    sleep 2
done

echo "✓ Database is ready"
echo ""

# Seed the database
echo "Seeding database with initial data..."
docker-compose exec -T app python seed_database.py

echo ""
echo "=================================================="
echo "✅ Setup Complete!"
echo "=================================================="
echo ""
echo "🌐 Application is running at: http://localhost:8000"
echo "📚 API Documentation: http://localhost:8000/docs"
echo "📖 Alternative Docs: http://localhost:8000/redoc"
echo ""
echo "🔐 Test Credentials:"
echo "--------------------"
echo "Admin:    user_id=admin001    password=admin123"
echo "Manager:  user_id=mgr001      password=manager123"
echo "Provider: user_id=dr001       password=provider123"
echo "Patient:  user_id=pat001      password=patient123"
echo ""
echo "📋 Useful Commands:"
echo "--------------------"
echo "View logs:           docker-compose logs -f app"
echo "Stop application:    docker-compose down"
echo "Restart application: docker-compose restart"
echo "View database:       docker-compose exec db psql -U postgres healthcare_db"
echo ""
echo "📚 Documentation:"
echo "--------------------"
echo "README:              cat README.md"
echo "API Testing Guide:   cat API_TESTING_GUIDE.md"
echo "Deployment Guide:    cat DEPLOYMENT.md"
echo ""
echo "Example API Call (Login):"
echo '--------------------'
echo 'curl -X POST "http://localhost:8000/api/v1/auth/login" \'
echo '  -H "Content-Type: application/x-www-form-urlencoded" \'
echo '  -d "username=pat001&password=patient123"'
echo ""
