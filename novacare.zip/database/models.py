from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Enum, Text, Time, Date, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .db import Base
import enum


class UserRole(str, enum.Enum):
    PATIENT = "patient"
    PROVIDER = "provider"
    ADMIN = "admin"
    MANAGER = "manager"


class AppointmentStatus(str, enum.Enum):
    REQUESTED = "requested"
    CONFIRMED = "confirmed"
    CHECKED_IN = "checked_in"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


class AppointmentPriority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class AuditAction(str, enum.Enum):
    CREATE = "create"
    MODIFY = "modify"
    CANCEL = "cancel"
    APPROVE = "approve"
    REJECT = "reject"
    CHECK_IN = "check_in"
    COMPLETE = "complete"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, unique=True, nullable=False, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    patient_profile = relationship("Patient", back_populates="user", uselist=False, cascade="all, delete-orphan")
    provider_profile = relationship("Provider", back_populates="user", uselist=False, cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user", cascade="all, delete-orphan")


class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    phone_number = Column(String)
    date_of_birth = Column(Date)
    address = Column(Text)
    emergency_contact = Column(String)
    medical_record_number = Column(String, unique=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    user = relationship("User", back_populates="patient_profile")
    appointments = relationship("Appointment", back_populates="patient", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="patient", cascade="all, delete-orphan")


class Clinic(Base):
    __tablename__ = "clinics"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    address = Column(Text, nullable=False)
    phone_number = Column(String)
    email = Column(String)
    operating_hours_start = Column(Time)
    operating_hours_end = Column(Time)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    examination_rooms = relationship("ExaminationRoom", back_populates="clinic", cascade="all, delete-orphan")
    providers = relationship("Provider", back_populates="clinic")
    service_types = relationship("ServiceType", back_populates="clinic", cascade="all, delete-orphan")
    appointments = relationship("Appointment", back_populates="clinic")


class Provider(Base):
    __tablename__ = "providers"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False)
    specialty = Column(String, nullable=False)
    license_number = Column(String, unique=True)
    phone_number = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    user = relationship("User", back_populates="provider_profile")
    clinic = relationship("Clinic", back_populates="providers")
    availability = relationship("ProviderAvailability", back_populates="provider", cascade="all, delete-orphan")
    appointments = relationship("Appointment", back_populates="provider")


class ProviderAvailability(Base):
    __tablename__ = "provider_availability"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False)
    day_of_week = Column(Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    provider = relationship("Provider", back_populates="availability")


class ProviderUnavailability(Base):
    __tablename__ = "provider_unavailability"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False)
    start_datetime = Column(DateTime(timezone=True), nullable=False)
    end_datetime = Column(DateTime(timezone=True), nullable=False)
    reason = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    provider = relationship("Provider")


class ExaminationRoom(Base):
    __tablename__ = "examination_rooms"

    id = Column(Integer, primary_key=True, index=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False)
    room_number = Column(String, nullable=False)
    room_type = Column(String)  # e.g., "standard", "procedure", "consultation"
    capacity = Column(Integer, default=1)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    clinic = relationship("Clinic", back_populates="examination_rooms")
    appointments = relationship("Appointment", back_populates="examination_room")


class MedicalEquipment(Base):
    __tablename__ = "medical_equipment"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    equipment_type = Column(String, nullable=False)
    model_number = Column(String)
    serial_number = Column(String, unique=True)
    is_available = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    appointment_equipment = relationship("AppointmentEquipment", back_populates="equipment")


class ServiceType(Base):
    __tablename__ = "service_types"

    id = Column(Integer, primary_key=True, index=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text)
    duration_minutes = Column(Integer, nullable=False, default=30)
    requires_equipment = Column(Boolean, default=False)
    priority_level = Column(Enum(AppointmentPriority), default=AppointmentPriority.MEDIUM)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    clinic = relationship("Clinic", back_populates="service_types")
    appointments = relationship("Appointment", back_populates="service_type")


class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False)
    service_type_id = Column(Integer, ForeignKey("service_types.id"), nullable=False)
    examination_room_id = Column(Integer, ForeignKey("examination_rooms.id"))

    appointment_datetime = Column(DateTime(timezone=True), nullable=False, index=True)
    duration_minutes = Column(Integer, nullable=False, default=30)
    status = Column(Enum(AppointmentStatus), default=AppointmentStatus.REQUESTED, nullable=False)
    priority = Column(Enum(AppointmentPriority), default=AppointmentPriority.MEDIUM)

    is_after_hours = Column(Boolean, default=False)
    requires_approval = Column(Boolean, default=False)
    approved_by = Column(Integer, ForeignKey("users.id"))

    notes = Column(Text)
    cancellation_reason = Column(Text)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    checked_in_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    cancelled_at = Column(DateTime(timezone=True))

    # Relationships
    patient = relationship("Patient", back_populates="appointments")
    provider = relationship("Provider", back_populates="appointments")
    clinic = relationship("Clinic", back_populates="appointments")
    service_type = relationship("ServiceType", back_populates="appointments")
    examination_room = relationship("ExaminationRoom", back_populates="appointments")
    approver = relationship("User", foreign_keys=[approved_by])
    equipment_assignments = relationship("AppointmentEquipment", back_populates="appointment",
                                         cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="appointment", cascade="all, delete-orphan")


class AppointmentEquipment(Base):
    __tablename__ = "appointment_equipment"

    id = Column(Integer, primary_key=True, index=True)
    appointment_id = Column(Integer, ForeignKey("appointments.id"), nullable=False)
    equipment_id = Column(Integer, ForeignKey("medical_equipment.id"), nullable=False)
    assigned_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    appointment = relationship("Appointment", back_populates="equipment_assignments")
    equipment = relationship("MedicalEquipment", back_populates="appointment_equipment")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    appointment_id = Column(Integer, ForeignKey("appointments.id"))
    message = Column(Text, nullable=False)
    notification_type = Column(String, nullable=False)  # "confirmed", "rescheduled", "cancelled"
    is_read = Column(Boolean, default=False)
    sent_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    patient = relationship("Patient", back_populates="notifications")
    appointment = relationship("Appointment")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    appointment_id = Column(Integer, ForeignKey("appointments.id"))
    action = Column(Enum(AuditAction), nullable=False)
    details = Column(Text)
    ip_address = Column(String)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    # Relationships
    user = relationship("User", back_populates="audit_logs")
    appointment = relationship("Appointment", back_populates="audit_logs")


class Schedule(Base):
    __tablename__ = "schedules"

    id = Column(Integer, primary_key=True, index=True)
    clinic_id = Column(Integer, ForeignKey("clinics.id"), nullable=False)
    schedule_date = Column(Date, nullable=False, index=True)
    generated_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    is_official = Column(Boolean, default=False)
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    clinic = relationship("Clinic")
    generator = relationship("User")