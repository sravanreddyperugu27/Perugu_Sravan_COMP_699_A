from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from typing import List, Optional
from datetime import datetime, date, timedelta

from database.db import get_db
from database.models import (
    User, Appointment, Schedule, ServiceType, Provider, Patient, Clinic,
    ExaminationRoom, MedicalEquipment, AppointmentEquipment,
    AppointmentStatus, AppointmentPriority, UserRole, AuditAction
)
from schemas.schema import (
    ScheduleCreate, ScheduleResponse, ServiceTypeCreate, ServiceTypeResponse,
    AppointmentVolumeReport, ProviderUtilizationReport, WaitTimeReport,
    ResourceUtilizationReport, AppointmentResponse
)
from services.auth import require_role
from services.service import AppointmentService

router = APIRouter(prefix="/api/v1/managers", tags=["Managers"])


@router.get("/appointments/pending-approval", response_model=List[AppointmentResponse])
def get_pending(db: Session = Depends(get_db), user: User = Depends(require_role([UserRole.MANAGER]))):
    """
    Req 2.4.1, 2.4.2, 2.4.3: View pending approvals (High Priority, After Hours, Overrides)
    """
    return db.query(Appointment).filter(
        Appointment.requires_approval == True,
        Appointment.status == AppointmentStatus.REQUESTED,
        Appointment.approved_by == None
    ).all()


@router.put("/appointments/{id}/approve", response_model=AppointmentResponse)
def approve(id: int, req: Request, db: Session = Depends(get_db),
            user: User = Depends(require_role([UserRole.MANAGER]))):
    """Req 2.4.1 - 2.4.3"""
    apt = db.query(Appointment).filter(Appointment.id == id).first()
    if not apt: raise HTTPException(404, "Not found")

    apt.approved_by = user.id
    apt.status = AppointmentStatus.CONFIRMED
    db.commit()

    AppointmentService.create_notification(db, apt.patient_id, apt.id, "confirmed", "Appointment Approved")
    AppointmentService.create_audit_log(db, user.id, AuditAction.APPROVE, apt.id, "Manager Approved", req.client.host)
    return apt


@router.put("/appointments/{id}/reject-approval")
def reject(id: int, reason: str, req: Request, db: Session = Depends(get_db),
           user: User = Depends(require_role([UserRole.MANAGER]))):
    apt = db.query(Appointment).filter(Appointment.id == id).first()
    if not apt: raise HTTPException(404, "Not found")

    apt.status = AppointmentStatus.REJECTED
    apt.cancellation_reason = reason
    db.commit()

    AppointmentService.create_notification(db, apt.patient_id, apt.id, "rejected", f"Rejected: {reason}")
    AppointmentService.create_audit_log(db, user.id, AuditAction.REJECT, apt.id, f"Manager Rejected: {reason}",
                                        req.client.host)
    return {"message": "Rejected"}


# Schedule Management
@router.post("/schedules/generate", response_model=ScheduleResponse, status_code=status.HTTP_201_CREATED)
def generate_official_schedule(
        schedule_data: ScheduleCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER, UserRole.ADMIN]))
):
    """
    Requirement 2.4.4: Manager generates official clinic schedules
    """

    # Check if official schedule already exists for this date
    existing = db.query(Schedule).filter(
        Schedule.clinic_id == schedule_data.clinic_id,
        Schedule.schedule_date == schedule_data.schedule_date,
        Schedule.is_official == True
    ).first()

    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Official schedule already exists for this date"
        )

    # Create official schedule
    new_schedule = Schedule(
        clinic_id=schedule_data.clinic_id,
        schedule_date=schedule_data.schedule_date,
        generated_by=current_user.id,
        is_official=True,
        notes=schedule_data.notes
    )

    db.add(new_schedule)
    db.commit()
    db.refresh(new_schedule)

    # Create audit log
    AppointmentService.create_audit_log(
        db,
        user_id=current_user.id,
        action=AuditAction.CREATE,
        appointment_id=None,
        details=f"Official schedule generated for clinic {schedule_data.clinic_id} on {schedule_data.schedule_date}",
        ip_address=None
    )

    return new_schedule


@router.get("/schedules", response_model=List[ScheduleResponse])
def list_schedules(
        clinic_id: Optional[int] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        official_only: bool = True,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER, UserRole.ADMIN]))
):
    """
    List generated schedules with optional filters
    """

    query = db.query(Schedule)

    if official_only:
        query = query.filter(Schedule.is_official == True)

    if clinic_id:
        query = query.filter(Schedule.clinic_id == clinic_id)

    if start_date:
        query = query.filter(Schedule.schedule_date >= start_date)

    if end_date:
        query = query.filter(Schedule.schedule_date <= end_date)

    schedules = query.order_by(Schedule.schedule_date.desc()).all()

    return schedules


@router.delete("/schedules/{schedule_id}")
def delete_schedule(
        schedule_id: int,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER, UserRole.ADMIN]))
):
    """Delete a generated schedule"""

    schedule = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not schedule:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found"
        )

    db.delete(schedule)
    db.commit()

    return {"message": "Schedule deleted successfully"}


# Service Type Priority Management
@router.put("/service-types/{service_type_id}/priority", response_model=ServiceTypeResponse)
def update_service_priority(
        service_type_id: int,
        priority: AppointmentPriority,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Requirement 2.4.5: Manager defines priority levels for appointment types
    """

    service_type = db.query(ServiceType).filter(ServiceType.id == service_type_id).first()
    if not service_type:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Service type not found"
        )

    old_priority = service_type.priority_level
    service_type.priority_level = priority
    db.commit()
    db.refresh(service_type)

    # Create audit log
    AppointmentService.create_audit_log(
        db,
        user_id=current_user.id,
        action=AuditAction.MODIFY,
        appointment_id=None,
        details=f"Service type {service_type.name} priority changed from {old_priority} to {priority}",
        ip_address=None
    )

    return service_type


# Reporting
@router.get("/reports/appointment-volume", response_model=List[AppointmentVolumeReport])
def get_appointment_volume_report(
        start_date: date,
        end_date: date,
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Requirement 2.4.6: Manager views operational reports on appointment volume
    """

    query = db.query(
        Appointment.clinic_id,
        Clinic.name.label('clinic_name'),
        func.date(Appointment.appointment_datetime).label('date'),
        func.count(Appointment.id).label('total_appointments'),
        func.sum(case((Appointment.status == AppointmentStatus.REQUESTED, 1), else_=0)).label('requested'),
        func.sum(case((Appointment.status == AppointmentStatus.CONFIRMED, 1), else_=0)).label('confirmed'),
        func.sum(case((Appointment.status == AppointmentStatus.COMPLETED, 1), else_=0)).label('completed'),
        func.sum(case((Appointment.status == AppointmentStatus.CANCELLED, 1), else_=0)).label('cancelled'),
        func.sum(case((Appointment.is_after_hours == True, 1), else_=0)).label('after_hours')
    ).join(Clinic).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        query = query.filter(Appointment.clinic_id == clinic_id)

    results = query.group_by(
        Appointment.clinic_id,
        Clinic.name,
        func.date(Appointment.appointment_datetime)
    ).all()

    reports = []
    for row in results:
        reports.append(AppointmentVolumeReport(
            clinic_id=row.clinic_id,
            clinic_name=row.clinic_name,
            date=row.date,
            total_appointments=row.total_appointments,
            requested=row.requested or 0,
            confirmed=row.confirmed or 0,
            completed=row.completed or 0,
            cancelled=row.cancelled or 0,
            after_hours=row.after_hours or 0
        ))

    return reports


@router.get("/reports/provider-utilization", response_model=List[ProviderUtilizationReport])
def get_provider_utilization_report(
        start_date: date,
        end_date: date,
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Requirement 2.4.8: Manager views reports on provider utilization
    """

    query = db.query(
        Provider.id.label('provider_id'),
        User.full_name.label('provider_name'),
        Provider.specialty,
        func.count(Appointment.id).label('total_appointments'),
        func.sum(case((Appointment.status == AppointmentStatus.COMPLETED, 1), else_=0)).label('completed_appointments'),
        func.sum(case((Appointment.status == AppointmentStatus.CANCELLED, 1), else_=0)).label('cancelled_appointments'),
        func.sum(Appointment.duration_minutes).label('total_scheduled_minutes')
    ).join(User, Provider.user_id == User.id).outerjoin(Appointment).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        query = query.filter(Provider.clinic_id == clinic_id)

    results = query.group_by(
        Provider.id,
        User.full_name,
        Provider.specialty
    ).all()

    reports = []
    for row in results:
        total = row.total_appointments or 0
        completed = row.completed_appointments or 0
        utilization_rate = (completed / total * 100) if total > 0 else 0

        reports.append(ProviderUtilizationReport(
            provider_id=row.provider_id,
            provider_name=row.provider_name,
            specialty=row.specialty,
            total_appointments=total,
            completed_appointments=completed,
            cancelled_appointments=row.cancelled_appointments or 0,
            utilization_rate=round(utilization_rate, 2),
            total_scheduled_minutes=row.total_scheduled_minutes or 0
        ))

    return reports


@router.get("/reports/wait-times", response_model=WaitTimeReport)
def get_wait_time_report(
        start_date: date,
        end_date: date,
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Requirement 2.4.7: Manager views reports on patient wait times
    """

    # Calculate wait time as difference between checked-in time and appointment time
    query = db.query(Appointment).filter(
        Appointment.status == AppointmentStatus.COMPLETED,
        Appointment.checked_in_at != None,
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        query = query.filter(Appointment.clinic_id == clinic_id)

    appointments = query.all()

    if not appointments:
        return WaitTimeReport(
            average_wait_minutes=0,
            median_wait_minutes=0,
            max_wait_minutes=0,
            min_wait_minutes=0,
            total_appointments=0
        )

    wait_times = []
    for apt in appointments:
        # Calculate wait time in minutes (how late the check-in was compared to scheduled time)
        wait_seconds = (apt.checked_in_at - apt.appointment_datetime).total_seconds()
        wait_minutes = max(0, wait_seconds / 60)  # Negative values mean early check-in
        wait_times.append(wait_minutes)

    wait_times.sort()

    avg_wait = sum(wait_times) / len(wait_times)
    median_wait = wait_times[len(wait_times) // 2]
    max_wait = max(wait_times)
    min_wait = min(wait_times)

    return WaitTimeReport(
        average_wait_minutes=round(avg_wait, 2),
        median_wait_minutes=round(median_wait, 2),
        max_wait_minutes=round(max_wait, 2),
        min_wait_minutes=round(min_wait, 2),
        total_appointments=len(appointments)
    )


@router.get("/reports/resource-utilization", response_model=List[ResourceUtilizationReport])
def get_resource_utilization_report(
        start_date: date,
        end_date: date,
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Requirement 2.4.9: Manager views reports on room and equipment utilization
    """

    reports = []

    # Room utilization
    room_query = db.query(
        ExaminationRoom.id,
        ExaminationRoom.room_number,
        ExaminationRoom.room_type,
        func.count(Appointment.id).label('total_bookings'),
        func.sum(Appointment.duration_minutes).label('total_minutes_used')
    ).outerjoin(Appointment).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date,
        Appointment.status != AppointmentStatus.CANCELLED
    )

    if clinic_id:
        room_query = room_query.filter(ExaminationRoom.clinic_id == clinic_id)

    room_results = room_query.group_by(
        ExaminationRoom.id,
        ExaminationRoom.room_number,
        ExaminationRoom.room_type
    ).all()

    # Calculate total possible minutes (simplified: 8 hours/day)
    days = (end_date - start_date).days + 1
    total_minutes_available = days * 8 * 60  # 8 hours per day

    for row in room_results:
        total_minutes = row.total_minutes_used or 0
        utilization = (total_minutes / total_minutes_available * 100) if total_minutes_available > 0 else 0
        reports.append(ResourceUtilizationReport(
            resource_type="examination_room",
            resource_name=f"Room {row.room_number} ({row.room_type})",
            total_bookings=row.total_bookings or 0,
            total_minutes_used=total_minutes,
            utilization_rate=round(utilization, 2)
        ))

    # Equipment utilization
    equipment_query = db.query(
        MedicalEquipment.id,
        MedicalEquipment.name,
        MedicalEquipment.equipment_type,
        func.count(AppointmentEquipment.id).label('total_bookings'),
        func.sum(Appointment.duration_minutes).label('total_minutes_used')
    ).outerjoin(AppointmentEquipment).outerjoin(Appointment).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date,
        Appointment.status != AppointmentStatus.CANCELLED
    ).group_by(
        MedicalEquipment.id,
        MedicalEquipment.name,
        MedicalEquipment.equipment_type
    ).all()

    for row in equipment_query:
        total_minutes = row.total_minutes_used or 0
        utilization = (total_minutes / total_minutes_available * 100) if total_minutes_available > 0 else 0
        reports.append(ResourceUtilizationReport(
            resource_type="medical_equipment",
            resource_name=f"{row.name} ({row.equipment_type})",
            total_bookings=row.total_bookings or 0,
            total_minutes_used=total_minutes,
            utilization_rate=round(utilization, 2)
        ))

    return reports


@router.get("/reports/summary")
def get_summary_report(
        start_date: date,
        end_date: date,
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.MANAGER]))
):
    """
    Comprehensive summary report combining all key metrics
    Requirements 2.4.6, 2.4.7, 2.4.8, 2.4.9
    """

    # Get appointment statistics
    apt_query = db.query(
        func.count(Appointment.id).label('total'),
        func.sum(case((Appointment.status == AppointmentStatus.COMPLETED, 1), else_=0)).label('completed'),
        func.sum(case((Appointment.status == AppointmentStatus.CANCELLED, 1), else_=0)).label('cancelled'),
        func.sum(case((Appointment.is_after_hours == True, 1), else_=0)).label('after_hours'),
        func.sum(case((Appointment.requires_approval == True, 1), else_=0)).label('required_approval')
    ).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        apt_query = apt_query.filter(Appointment.clinic_id == clinic_id)

    apt_stats = apt_query.first()

    # Calculate average wait time
    wait_query = db.query(Appointment).filter(
        Appointment.status == AppointmentStatus.COMPLETED,
        Appointment.checked_in_at != None,
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        wait_query = wait_query.filter(Appointment.clinic_id == clinic_id)

    wait_appointments = wait_query.all()

    avg_wait = 0
    if wait_appointments:
        wait_times = [(apt.checked_in_at - apt.appointment_datetime).total_seconds() / 60
                      for apt in wait_appointments]
        avg_wait = sum(wait_times) / len(wait_times)

    # Get provider count
    provider_query = db.query(func.count(Provider.id)).join(Appointment).filter(
        func.date(Appointment.appointment_datetime) >= start_date,
        func.date(Appointment.appointment_datetime) <= end_date
    )

    if clinic_id:
        provider_query = provider_query.filter(Provider.clinic_id == clinic_id)

    active_providers = provider_query.scalar() or 0

    return {
        "period": {
            "start_date": start_date,
            "end_date": end_date
        },
        "appointments": {
            "total": apt_stats.total or 0,
            "completed": apt_stats.completed or 0,
            "cancelled": apt_stats.cancelled or 0,
            "completion_rate": round((apt_stats.completed / apt_stats.total * 100) if apt_stats.total else 0, 2),
            "cancellation_rate": round((apt_stats.cancelled / apt_stats.total * 100) if apt_stats.total else 0, 2)
        },
        "after_hours": {
            "total": apt_stats.after_hours or 0,
            "required_approval": apt_stats.required_approval or 0
        },
        "wait_times": {
            "average_minutes": round(avg_wait, 2)
        },
        "providers": {
            "active_count": active_providers
        }
    }