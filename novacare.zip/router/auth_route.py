# --- START OF FILE router/auth_route.py ---

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta

from database.db import get_db
from database.models import User, Patient, UserRole
from schemas.schema import (
    PatientRegister, StaffRegister, UserResponse, Token,
    UserCreate  # Keep if used elsewhere
)
from services.auth import (
    authenticate_user, create_access_token, get_password_hash,
    ACCESS_TOKEN_EXPIRE_MINUTES, get_current_active_user, require_role
)

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])


@router.post("/register/patient", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_patient(user: PatientRegister, db: Session = Depends(get_db)):
    """Public route: Always creates a PATIENT"""

    if db.query(User).filter(User.user_id == user.user_id).first():
        raise HTTPException(status_code=400, detail="User ID already exists")
    if db.query(User).filter(User.email == user.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    # Force Role to PATIENT
    db_user = User(
        user_id=user.user_id,
        email=user.email,
        full_name=user.full_name,
        role=UserRole.PATIENT,
        hashed_password=get_password_hash(user.password)
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    # Auto-create Patient Profile
    db_patient = Patient(
        user_id=db_user.id,
        medical_record_number=f"MRN-{db_user.id}-{1000 + db_user.id}"
    )
    db.add(db_patient)
    db.commit()

    return db_user


@router.post("/register/staff", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_staff(
        user: StaffRegister,
        db: Session = Depends(get_db),
        # SECURITY: Only an existing ADMIN can create staff
        current_admin: User = Depends(require_role([UserRole.ADMIN]))
):
    """Protected route: Admin creates Managers/Providers/Admins"""

    if db.query(User).filter(User.user_id == user.user_id).first():
        raise HTTPException(status_code=400, detail="User ID already exists")

    db_user = User(
        user_id=user.user_id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,  # Role is allowed here
        hashed_password=get_password_hash(user.password)
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@router.post("/login", response_model=Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect user ID or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.user_id}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}


@router.get("/me", response_model=UserResponse)
def get_current_user_info(current_user: User = Depends(get_current_active_user)):
    return current_user