from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from database.db import get_db
from database.models import (
    User, Appointment, ExaminationRoom, MedicalEquipment, AppointmentEquipment,
    Clinic, ServiceType, AppointmentStatus, UserRole, AuditAction, Patient, Provider
)
from schemas.schema import (
    AppointmentCreate, AppointmentUpdate, AppointmentResponse,
    ExaminationRoomCreate, ExaminationRoomResponse, MedicalEquipmentCreate,
    MedicalEquipmentResponse, AppointmentEquipmentCreate, AppointmentEquipmentResponse,
    ClinicCreate, ClinicResponse, ServiceTypeCreate, ServiceTypeResponse,
    AppointmentDetailResponse, ConflictReport
)
from services.auth import require_role, get_current_active_user
from services.service import AppointmentService

router = APIRouter(prefix="/api/v1/admin", tags=["Administration"])


# Clinic Management
@router.post("/clinics", response_model=ClinicResponse, status_code=status.HTTP_201_CREATED)
def create_clinic(
        clinic: ClinicCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN, UserRole.MANAGER]))
):
    """Create a new clinic"""
    db_clinic = Clinic(**clinic.dict())
    db.add(db_clinic)
    db.commit()
    db.refresh(db_clinic)
    return db_clinic


@router.get("/clinics", response_model=List[ClinicResponse])
def list_clinics(
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """List all clinics"""
    clinics = db.query(Clinic).all()
    return clinics


# Service Type Management
@router.post("/service-types", response_model=ServiceTypeResponse, status_code=status.HTTP_201_CREATED)
def create_service_type(
        service_type: ServiceTypeCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN, UserRole.MANAGER]))
):
    """Create a new service type"""
    db_service = ServiceType(**service_type.dict())
    db.add(db_service)
    db.commit()
    db.refresh(db_service)
    return db_service


@router.get("/service-types", response_model=List[ServiceTypeResponse])
def list_service_types(
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """List service types"""
    query = db.query(ServiceType)
    if clinic_id:
        query = query.filter(ServiceType.clinic_id == clinic_id)
    return query.all()


# Examination Room Management
@router.post("/examination-rooms", response_model=ExaminationRoomResponse, status_code=status.HTTP_201_CREATED)
def create_examination_room(
        room: ExaminationRoomCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """Create a new examination room"""
    db_room = ExaminationRoom(**room.dict())
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    return db_room


@router.get("/examination-rooms", response_model=List[ExaminationRoomResponse])
def list_examination_rooms(
        clinic_id: Optional[int] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """List examination rooms"""
    query = db.query(ExaminationRoom).filter(ExaminationRoom.is_active == True)
    if clinic_id:
        query = query.filter(ExaminationRoom.clinic_id == clinic_id)
    return query.all()


# Medical Equipment Management
@router.post("/medical-equipment", response_model=MedicalEquipmentResponse, status_code=status.HTTP_201_CREATED)
def create_medical_equipment(
        equipment: MedicalEquipmentCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """Create a new medical equipment record"""
    db_equipment = MedicalEquipment(**equipment.dict())
    db.add(db_equipment)
    db.commit()
    db.refresh(db_equipment)
    return db_equipment


@router.get("/medical-equipment", response_model=List[MedicalEquipmentResponse])
def list_medical_equipment(
        available_only: bool = False,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """List medical equipment"""
    query = db.query(MedicalEquipment).filter(MedicalEquipment.is_active == True)
    if available_only:
        query = query.filter(MedicalEquipment.is_available == True)
    return query.all()


@router.post("/appointments", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED)
def create_appointment_on_behalf(
        appointment_data: AppointmentCreate,
        patient_id: int,
        request: Request,
        force_override: bool = False,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """Req 2.3.1: Admin creates appointment."""
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient: raise HTTPException(404, "Patient not found")

    svc = db.query(ServiceType).filter(ServiceType.id == appointment_data.service_type_id).first()
    if not svc: raise HTTPException(404, "Service Type not found")

    provider_id = appointment_data.provider_id or AppointmentService.auto_assign_provider(
        db, appointment_data.clinic_id, appointment_data.service_type_id,
        appointment_data.appointment_datetime, svc.duration_minutes
    )

    if not provider_id and not force_override:
        raise HTTPException(400, "No provider available. Use force_override.")

    conflict = False
    if provider_id:
        if not AppointmentService.check_provider_availability(db, provider_id, appointment_data.appointment_datetime,
                                                              svc.duration_minutes):
            conflict = True
            if not force_override: raise HTTPException(400, "Provider unavailable. Use force_override.")

    is_after_hours = AppointmentService.is_after_hours(db, appointment_data.clinic_id,
                                                       appointment_data.appointment_datetime)

    requires_approval = is_after_hours or (conflict and force_override)
    status_code = AppointmentStatus.REQUESTED if requires_approval else AppointmentStatus.CONFIRMED

    new_appointment = Appointment(
        patient_id=patient_id,
        provider_id=provider_id,
        clinic_id=appointment_data.clinic_id,
        service_type_id=appointment_data.service_type_id,
        appointment_datetime=appointment_data.appointment_datetime,
        duration_minutes=svc.duration_minutes,
        priority=appointment_data.priority,
        notes=appointment_data.notes,
        status=status_code,
        is_after_hours=is_after_hours,
        requires_approval=requires_approval
    )
    db.add(new_appointment)
    db.commit()
    db.refresh(new_appointment)

    AppointmentService.allocate_resources(db, new_appointment)
    db.commit()

    AppointmentService.create_audit_log(
        db, current_user.id, AuditAction.CREATE, new_appointment.id,
        f"Admin created. Override: {force_override}. Conflict detected: {conflict}", request.client.host
    )
    return new_appointment


@router.put("/appointments/{appointment_id}", response_model=AppointmentResponse)
def modify_appointment(
        appointment_id: int, appointment_update: AppointmentUpdate, request: Request,
        force_override: bool = False, db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """Req 2.3.2: Admin modifies appointment."""
    apt = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not apt: raise HTTPException(404, "Appointment not found")

    new_dt = appointment_update.appointment_datetime or apt.appointment_datetime
    new_prov = appointment_update.provider_id or apt.provider_id

    conflict = False
    if new_prov != apt.provider_id or new_dt != apt.appointment_datetime:
        if not AppointmentService.check_provider_availability(db, new_prov, new_dt, apt.duration_minutes,
                                                              exclude_appointment_id=apt.id):
            conflict = True
            if not force_override: raise HTTPException(400, "Provider unavailable. Use override.")

    if appointment_update.provider_id: apt.provider_id = appointment_update.provider_id
    if appointment_update.appointment_datetime: apt.appointment_datetime = appointment_update.appointment_datetime
    if appointment_update.status: apt.status = appointment_update.status
    if appointment_update.priority: apt.priority = appointment_update.priority

    if conflict and force_override:
        apt.requires_approval = True
        apt.status = AppointmentStatus.REQUESTED

    db.commit()
    AppointmentService.create_audit_log(db, current_user.id, AuditAction.MODIFY, apt.id,
                                        f"Admin modified. Override: {force_override}", request.client.host)
    return apt


@router.delete("/appointments/{appointment_id}/cancel")
def cancel_appointment_by_admin(
        appointment_id: int,
        reason: str,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment: raise HTTPException(404, "Appointment not found")

    if appointment.status == AppointmentStatus.CANCELLED:
        raise HTTPException(400, "Appointment is already cancelled")

    appointment.status = AppointmentStatus.CANCELLED
    appointment.cancelled_at = datetime.now()
    appointment.cancellation_reason = reason

    db.commit()

    AppointmentService.create_audit_log(
        db, current_user.id, AuditAction.CANCEL, appointment.id,
        f"Appointment cancelled by admin. Reason: {reason}", request.client.host
    )
    return {"message": "Appointment cancelled successfully"}


@router.post("/appointments/{appointment_id}/assign-room")
def assign_room(appointment_id: int, room_id: int, request: Request, force_override: bool = False,
                db: Session = Depends(get_db), current_user: User = Depends(require_role([UserRole.ADMIN]))):
    apt = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not apt: raise HTTPException(404, "Not found")

    if not force_override:
        if not AppointmentService.check_room_availability(db, room_id, apt.appointment_datetime, apt.duration_minutes,
                                                          apt.id):
            raise HTTPException(400, "Room unavailable")

    apt.examination_room_id = room_id
    db.commit()
    AppointmentService.create_audit_log(db, current_user.id, AuditAction.MODIFY, apt.id, f"Assigned Room {room_id}",
                                        request.client.host)
    return {"message": "Room assigned"}


@router.post("/appointments/{appointment_id}/assign-equipment")
def assign_equipment(appointment_id: int, equipment_id: int, request: Request, force_override: bool = False,
                     db: Session = Depends(get_db), current_user: User = Depends(require_role([UserRole.ADMIN]))):
    apt = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not apt: raise HTTPException(404, "Not found")

    if not force_override:
        if not AppointmentService.check_equipment_availability(db, equipment_id, apt.appointment_datetime,
                                                               apt.duration_minutes, apt.id):
            raise HTTPException(400, "Equipment unavailable")

    assign = AppointmentEquipment(appointment_id=appointment_id, equipment_id=equipment_id)
    db.add(assign)
    db.commit()
    AppointmentService.create_audit_log(db, current_user.id, AuditAction.MODIFY, apt.id,
                                        f"Assigned Equipment {equipment_id}", request.client.host)
    return assign


@router.delete("/appointments/{appointment_id}/equipment/{equipment_id}")
def remove_equipment_from_appointment(
        appointment_id: int, equipment_id: int, request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    assignment = db.query(AppointmentEquipment).filter(
        AppointmentEquipment.appointment_id == appointment_id,
        AppointmentEquipment.equipment_id == equipment_id
    ).first()

    if not assignment: raise HTTPException(404, "Equipment assignment not found")

    db.delete(assignment)
    db.commit()

    AppointmentService.create_audit_log(
        db, current_user.id, AuditAction.MODIFY, appointment_id,
        "Equipment removed from appointment", request.client.host
    )
    return {"message": "Equipment removed successfully"}


@router.get("/appointments/conflicts")
def identify_conflicts(db: Session = Depends(get_db), current_user: User = Depends(require_role([UserRole.ADMIN]))):
    apts = db.query(Appointment).filter(
        Appointment.status.in_([AppointmentStatus.CONFIRMED, AppointmentStatus.REQUESTED])).order_by(
        Appointment.appointment_datetime).all()

    conflicts = {"provider_conflicts": [], "room_conflicts": [], "equipment_conflicts": []}

    for i in range(len(apts)):
        for j in range(i + 1, len(apts)):
            a1, a2 = apts[i], apts[j]
            end1 = a1.appointment_datetime + timedelta(minutes=a1.duration_minutes)
            if a2.appointment_datetime < end1:
                if a1.provider_id == a2.provider_id:
                    conflicts["provider_conflicts"].append(
                        {"appointment_1": a1.id, "appointment_2": a2.id, "conflict_time": str(a1.appointment_datetime),
                         "severity": "high"})
                if a1.examination_room_id and a1.examination_room_id == a2.examination_room_id:
                    conflicts["room_conflicts"].append(
                        {"appointment_1": a1.id, "appointment_2": a2.id, "conflict_time": str(a1.appointment_datetime),
                         "severity": "medium"})
            else:
                break
    return conflicts


@router.get("/appointments", response_model=List[AppointmentDetailResponse])
def list_all_appointments(
        clinic_id: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        status: Optional[AppointmentStatus] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.ADMIN]))
):
    """List all appointments with detailed information"""
    query = db.query(Appointment)

    if clinic_id:
        query = query.filter(Appointment.clinic_id == clinic_id)
    if start_date:
        query = query.filter(Appointment.appointment_datetime >= start_date)
    if end_date:
        query = query.filter(Appointment.appointment_datetime <= end_date)
    if status:
        query = query.filter(Appointment.status == status)

    appointments = query.order_by(Appointment.appointment_datetime).all()

    result = []
    for apt in appointments:
        # FIX: Use AppointmentResponse (Base Schema) NOT AppointmentDetailResponse
        apt_dict = AppointmentResponse.from_orm(apt).dict()

        # Manually populate nested dicts for Pydantic V2 compatibility
        apt_dict['patient'] = None
        if apt.patient:
            patient_user = db.query(User).filter(User.id == apt.patient.user_id).first()
            apt_dict['patient'] = {
                'id': apt.patient.id,
                'full_name': patient_user.full_name if patient_user else 'Unknown'
            }

        apt_dict['provider'] = None
        if apt.provider:
            provider_user = db.query(User).filter(User.id == apt.provider.user_id).first()
            apt_dict['provider'] = {
                'id': apt.provider.id,
                'full_name': provider_user.full_name if provider_user else 'Unknown',
                'specialty': apt.provider.specialty
            }

        apt_dict['clinic'] = {'id': apt.clinic.id, 'name': apt.clinic.name} if apt.clinic else None
        apt_dict['service_type'] = {'id': apt.service_type.id,
                                    'name': apt.service_type.name} if apt.service_type else None

        apt_dict['examination_room'] = None
        if apt.examination_room:
            apt_dict['examination_room'] = {'id': apt.examination_room.id,
                                            'room_number': apt.examination_room.room_number}

        result.append(apt_dict)

    return result