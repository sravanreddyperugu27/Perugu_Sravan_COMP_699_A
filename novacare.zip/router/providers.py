from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, date, timedelta

from database.db import get_db
from database.models import (
    User, Provider, Appointment, ProviderAvailability, ProviderUnavailability,
    AppointmentStatus, UserRole, AuditAction, AppointmentEquipment, ExaminationRoom,
    MedicalEquipment, Patient
)
from schemas.schema import (
    ProviderCreate, ProviderResponse, ProviderAvailabilityCreate,
    ProviderAvailabilityResponse, ProviderUnavailabilityCreate,
    ProviderUnavailabilityResponse, AppointmentResponse, AppointmentDetailResponse
)
from services.auth import get_current_active_user, require_role
from services.service import AppointmentService

router = APIRouter(prefix="/api/v1/providers", tags=["Providers"])


# --- PROVIDER PROFILE ---

@router.post("/", response_model=ProviderResponse, status_code=status.HTTP_201_CREATED)
def create_provider(
        provider: ProviderCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Create a new provider profile"""
    if current_user.role not in [UserRole.ADMIN, UserRole.MANAGER]:
        if current_user.id != provider.user_id:
            raise HTTPException(status_code=403, detail="Not authorized")

    if db.query(Provider).filter(Provider.user_id == provider.user_id).first():
        raise HTTPException(status_code=400, detail="Provider profile already exists")

    db_provider = Provider(**provider.dict())
    db.add(db_provider)
    db.commit()
    db.refresh(db_provider)
    return db_provider


@router.get("/me", response_model=ProviderResponse)
def get_my_provider_profile(
        current_user: User = Depends(get_current_active_user),
        db: Session = Depends(get_db)
):
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider profile not found")
    return provider


# --- REQ 1 & 6: VIEW SCHEDULE & RESOURCES ---

@router.get("/schedule", response_model=List[AppointmentDetailResponse])
def get_my_schedule(
        view_by: str = Query("day", pattern="^(day|week|month)$"),
        start_date: Optional[date] = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    """
    View personal appointment schedule by day/week/month.
    Includes Examination Room and Equipment details.
    """
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider profile not found")

    if not start_date:
        start_date = date.today()

    # Determine Date Range
    if view_by == "day":
        end_date = start_date
    elif view_by == "week":
        # Start from the provided date, go 6 days forward
        end_date = start_date + timedelta(days=6)
    else:  # month
        # Start of month to End of month
        import calendar
        last_day = calendar.monthrange(start_date.year, start_date.month)[1]
        start_date = date(start_date.year, start_date.month, 1)
        end_date = date(start_date.year, start_date.month, last_day)

    # Convert to datetime for query
    start_dt = datetime.combine(start_date, datetime.min.time())
    end_dt = datetime.combine(end_date, datetime.max.time())

    appointments = db.query(Appointment).filter(
        Appointment.provider_id == provider.id,
        Appointment.appointment_datetime >= start_dt,
        Appointment.appointment_datetime <= end_dt,
        Appointment.status != AppointmentStatus.CANCELLED
    ).order_by(Appointment.appointment_datetime).all()

    # Build Detailed Response
    result = []
    for apt in appointments:
        # Convert base model to dictionary
        apt_dict = AppointmentResponse.from_orm(apt).dict()

        # 1. Add Patient Info
        apt_dict['patient'] = None
        if apt.patient:
            p_user = db.query(User).filter(User.id == apt.patient.user_id).first()
            apt_dict['patient'] = {
                'id': apt.patient.id,
                'full_name': p_user.full_name if p_user else "Unknown",
                'medical_record_number': apt.patient.medical_record_number
            }

        # 2. Add Clinic Info
        apt_dict['clinic'] = {'id': apt.clinic.id, 'name': apt.clinic.name} if apt.clinic else None

        # 3. Add Service Info
        apt_dict['service_type'] = {'id': apt.service_type.id,
                                    'name': apt.service_type.name} if apt.service_type else None

        # 4. Add Room Info (Req 6)
        apt_dict['examination_room'] = None
        if apt.examination_room:
            apt_dict['examination_room'] = {
                'id': apt.examination_room.id,
                'room_number': apt.examination_room.room_number
            }

        # 5. Add Equipment Info (Req 6)
        assignments = db.query(AppointmentEquipment).filter(AppointmentEquipment.appointment_id == apt.id).all()
        equip_list = []
        for assign in assignments:
            eq = db.query(MedicalEquipment).filter(MedicalEquipment.id == assign.equipment_id).first()
            if eq:
                equip_list.append({'id': eq.id, 'name': eq.name})

        # Manually attach equipment list (ensure schema allows this field or it is handled loosely)
        # Note: We must ensure AppointmentDetailResponse allows 'equipment' field or just pass it in response
        # Since Schema definition might vary, we add it to the dict.
        apt_dict['equipment'] = equip_list  # This assumes Schema has an optional 'equipment' field or is flexible

        result.append(apt_dict)

    return result


# --- REQ 2: AVAILABILITY MANAGEMENT ---

@router.get("/availability", response_model=List[ProviderAvailabilityResponse])
def get_my_availability(
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    if not provider: raise HTTPException(404, "Provider not found")
    return db.query(ProviderAvailability).filter(ProviderAvailability.provider_id == provider.id).order_by(
        ProviderAvailability.day_of_week).all()


@router.post("/availability", response_model=ProviderAvailabilityResponse)
def add_availability(
        avail: ProviderAvailabilityCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    if not provider: raise HTTPException(404, "Provider not found")

    # Check duplicate day
    if db.query(ProviderAvailability).filter(
            ProviderAvailability.provider_id == provider.id,
            ProviderAvailability.day_of_week == avail.day_of_week
    ).first():
        raise HTTPException(400, "Availability for this day already exists")

    db_avail = ProviderAvailability(provider_id=provider.id, **avail.dict(exclude={'provider_id'}))
    db.add(db_avail)
    db.commit()
    db.refresh(db_avail)
    return db_avail


@router.delete("/availability/{id}")
def delete_availability(
        id: int,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    item = db.query(ProviderAvailability).filter(ProviderAvailability.id == id,
                                                 ProviderAvailability.provider_id == provider.id).first()
    if not item: raise HTTPException(404, "Not found")
    db.delete(item)
    db.commit()
    return {"message": "Deleted"}


# --- REQ 3, 4, 5: APPOINTMENT ACTIONS ---

@router.put("/appointments/{appointment_id}/confirm", response_model=AppointmentResponse)
def confirm_appointment(
        appointment_id: int,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    """Req 3: Confirm appointment"""
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    apt = db.query(Appointment).filter(Appointment.id == appointment_id, Appointment.provider_id == provider.id).first()

    if not apt: raise HTTPException(404, "Appointment not found")
    if apt.status != AppointmentStatus.REQUESTED: raise HTTPException(400, "Must be in REQUESTED status")

    apt.status = AppointmentStatus.CONFIRMED
    db.commit()

    AppointmentService.create_notification(db, apt.patient_id, apt.id, "confirmed", "Provider Confirmed Appointment")
    return apt


@router.put("/appointments/{appointment_id}/reject", response_model=AppointmentResponse)
def reject_appointment(
        appointment_id: int,
        reason: str,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    """Req 3: Reject appointment"""
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    apt = db.query(Appointment).filter(Appointment.id == appointment_id, Appointment.provider_id == provider.id).first()

    if not apt: raise HTTPException(404, "Appointment not found")

    apt.status = AppointmentStatus.REJECTED
    apt.cancellation_reason = reason
    db.commit()

    AppointmentService.create_notification(db, apt.patient_id, apt.id, "rejected", f"Provider Rejected: {reason}")
    return apt


@router.put("/appointments/{appointment_id}/check-in", response_model=AppointmentResponse)
def check_in_patient(
        appointment_id: int,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    """Req 4: Check in patient"""
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    apt = db.query(Appointment).filter(Appointment.id == appointment_id, Appointment.provider_id == provider.id).first()

    if not apt: raise HTTPException(404, "Appointment not found")
    if apt.status != AppointmentStatus.CONFIRMED: raise HTTPException(400, "Appointment must be CONFIRMED to check in")

    apt.status = AppointmentStatus.CHECKED_IN
    apt.checked_in_at = datetime.now()
    db.commit()
    return apt


@router.put("/appointments/{appointment_id}/complete", response_model=AppointmentResponse)
def complete_appointment(
        appointment_id: int,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(require_role([UserRole.PROVIDER]))
):
    """Req 5: Complete appointment"""
    provider = db.query(Provider).filter(Provider.user_id == current_user.id).first()
    apt = db.query(Appointment).filter(Appointment.id == appointment_id, Appointment.provider_id == provider.id).first()

    if not apt: raise HTTPException(404, "Appointment not found")
    if apt.status != AppointmentStatus.CHECKED_IN: raise HTTPException(400, "Patient must be CHECKED_IN to complete")

    apt.status = AppointmentStatus.COMPLETED
    apt.completed_at = datetime.now()
    db.commit()
    return apt