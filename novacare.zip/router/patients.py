from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from database.db import get_db
from database.models import (
    User, Patient, Appointment, Notification, ServiceType,
    AppointmentStatus, UserRole, AuditAction
)
from schemas.schema import (
    PatientCreate, PatientResponse, AppointmentCreate, AppointmentResponse,
    AppointmentReschedule, NotificationResponse, AvailableSlot,
    AppointmentDetailResponse
)
from services.auth import get_current_active_user, require_role
from services.service import AppointmentService

router = APIRouter(prefix="/api/v1/patients", tags=["Patients"])


@router.post("/", response_model=PatientResponse, status_code=status.HTTP_201_CREATED)
def create_patient(
        patient: PatientCreate,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Create a new patient profile"""
    if current_user.role not in [UserRole.ADMIN, UserRole.MANAGER]:
        if current_user.id != patient.user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You are not authorized to create a profile for another user."
            )

    existing = db.query(Patient).filter(Patient.user_id == patient.user_id).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Patient profile already exists for this user"
        )

    db_patient = Patient(**patient.dict())
    db.add(db_patient)
    db.commit()
    db.refresh(db_patient)

    return db_patient


@router.get("/me", response_model=PatientResponse)
def get_my_patient_profile(
        current_user: User = Depends(get_current_active_user),
        db: Session = Depends(get_db)
):
    """Get current user's patient profile"""
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    return patient


@router.post("/appointments/request", response_model=AppointmentResponse)
def request_appointment(
        data: AppointmentCreate, request: Request, db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Req 2.1.1"""
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient: raise HTTPException(404, "Profile not found")

    svc = db.query(ServiceType).filter(ServiceType.id == data.service_type_id).first()
    if not svc: raise HTTPException(404, "Service not found")

    pid = data.provider_id or AppointmentService.auto_assign_provider(db, data.clinic_id, data.service_type_id,
                                                                      data.appointment_datetime, svc.duration_minutes)
    if not pid: raise HTTPException(400, "No provider available")

    # Conflict check
    if not AppointmentService.check_provider_availability(db, pid, data.appointment_datetime, svc.duration_minutes):
        raise HTTPException(400, "Provider not available")

    is_after_hours = AppointmentService.is_after_hours(db, data.clinic_id, data.appointment_datetime)
    req_approval = is_after_hours or data.priority in ['high', 'urgent']

    apt = Appointment(
        patient_id=patient.id, provider_id=pid, clinic_id=data.clinic_id, service_type_id=data.service_type_id,
        appointment_datetime=data.appointment_datetime, duration_minutes=svc.duration_minutes,
        priority=data.priority, notes=data.notes, status=AppointmentStatus.REQUESTED,
        is_after_hours=is_after_hours, requires_approval=req_approval
    )
    db.add(apt)
    db.commit()
    db.refresh(apt)

    # Req 2.5.2 & 2.5.3: System allocates resources
    AppointmentService.allocate_resources(db, apt)
    db.commit()

    AppointmentService.create_audit_log(db, current_user.id, AuditAction.CREATE, apt.id, "Patient requested",
                                        request.client.host)
    return apt


@router.get("/appointments/available-slots", response_model=List[AvailableSlot])
def get_available_slots(
        clinic_id: int,
        service_type_id: int,
        start_date: datetime,
        days_ahead: int = 7,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """
    Requirement 2.1.2: Patient views available appointment time slots
    """
    end_date = start_date + timedelta(days=days_ahead)

    service_type = db.query(ServiceType).filter(ServiceType.id == service_type_id).first()
    if not service_type:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Service type not found"
        )

    slots = AppointmentService.get_available_slots(
        db,
        clinic_id,
        service_type_id,
        start_date,
        end_date,
        service_type.duration_minutes
    )

    return slots


@router.get("/appointments", response_model=List[AppointmentDetailResponse])
def get_my_appointments(
        # FIX: Renamed argument to avoid shadowing 'status' module
        appointment_status: Optional[AppointmentStatus] = Query(None, alias="status"),
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """
    Requirement 2.1.5: Patient views the status of their appointments
    """
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()

    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    query = db.query(Appointment).filter(Appointment.patient_id == patient.id)

    if appointment_status:
        query = query.filter(Appointment.status == appointment_status)

    appointments = query.order_by(Appointment.appointment_datetime.desc()).all()

    # Enrich with related data
    result = []
    for apt in appointments:
        # FIX: Use AppointmentResponse (base) to serialize the SQL object.
        # This avoids Pydantic trying to validate the ORM relationships as Dictionaries.
        apt_dict = AppointmentResponse.from_orm(apt).dict()

        apt_dict['patient'] = {
            'id': patient.id,
            'full_name': current_user.full_name
        }

        if apt.provider:
            provider_user = db.query(User).filter(User.id == apt.provider.user_id).first()
            apt_dict['provider'] = {
                'id': apt.provider.id,
                'full_name': provider_user.full_name if provider_user else 'Unknown',
                'specialty': apt.provider.specialty
            }

        if apt.clinic:
            apt_dict['clinic'] = {
                'id': apt.clinic.id,
                'name': apt.clinic.name,
                'address': apt.clinic.address
            }

        if apt.service_type:
            apt_dict['service_type'] = {
                'id': apt.service_type.id,
                'name': apt.service_type.name
            }

        result.append(apt_dict)

    return result


@router.put("/appointments/{appointment_id}/reschedule", response_model=AppointmentResponse)
def reschedule_appointment(
        appointment_id: int,
        reschedule_data: AppointmentReschedule,
        request: Request,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """
    Requirement 2.1.3: Patient reschedules an existing appointment
    """
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.patient_id == patient.id
    ).first()

    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found"
        )

    AppointmentService.validate_reschedule(appointment, reschedule_data.appointment_datetime)

    if not AppointmentService.check_provider_availability(
            db,
            appointment.provider_id,
            reschedule_data.appointment_datetime,
            appointment.duration_minutes,
            exclude_appointment_id=appointment.id
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Provider is not available at the requested time"
        )

    old_datetime = appointment.appointment_datetime
    appointment.appointment_datetime = reschedule_data.appointment_datetime
    appointment.status = AppointmentStatus.REQUESTED

    db.commit()
    db.refresh(appointment)

    # Re-allocate resources for new time (Req 2.5.2)
    # Clear old assignments first to be safe, or just run allocate which checks availability
    # Simplified: Run allocate logic again
    AppointmentService.allocate_resources(db, appointment)
    db.commit()

    AppointmentService.create_notification(
        db,
        patient_id=patient.id,
        appointment_id=appointment.id,
        notification_type="rescheduled",
        message=f"Your appointment has been rescheduled from {old_datetime} to {reschedule_data.appointment_datetime}"
    )

    AppointmentService.create_audit_log(
        db,
        user_id=current_user.id,
        action=AuditAction.MODIFY,
        appointment_id=appointment.id,
        details=f"Appointment rescheduled from {old_datetime} to {reschedule_data.appointment_datetime}",
        ip_address=request.client.host if request.client else None
    )

    return appointment


@router.delete("/appointments/{appointment_id}/cancel")
def cancel_appointment(
        appointment_id: int,
        reason: str = None,
        request: Request = None,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """
    Requirement 2.1.4: Patient cancels an existing appointment
    """
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    appointment = db.query(Appointment).filter(
        Appointment.id == appointment_id,
        Appointment.patient_id == patient.id
    ).first()

    if not appointment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found"
        )

    if appointment.status == AppointmentStatus.CANCELLED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Appointment is already cancelled"
        )

    appointment.status = AppointmentStatus.CANCELLED
    appointment.cancelled_at = datetime.now()
    appointment.cancellation_reason = reason

    db.commit()

    AppointmentService.create_notification(
        db,
        patient_id=patient.id,
        appointment_id=appointment.id,
        notification_type="cancelled",
        message=f"Your appointment scheduled for {appointment.appointment_datetime} has been cancelled"
    )

    AppointmentService.create_audit_log(
        db,
        user_id=current_user.id,
        action=AuditAction.CANCEL,
        appointment_id=appointment.id,
        details=f"Appointment cancelled. Reason: {reason}",
        ip_address=request.client.host if request.client else None
    )

    return {"message": "Appointment cancelled successfully"}


@router.get("/notifications", response_model=List[NotificationResponse])
def get_my_notifications(
        unread_only: bool = False,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    """Requirement 2.1.6"""
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    query = db.query(Notification).filter(Notification.patient_id == patient.id)

    if unread_only:
        query = query.filter(Notification.is_read == False)

    notifications = query.order_by(Notification.sent_at.desc()).all()

    return notifications


@router.put("/notifications/{notification_id}/mark-read")
def mark_notification_read(
        notification_id: int,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_active_user)
):
    patient = db.query(Patient).filter(Patient.user_id == current_user.id).first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient profile not found"
        )

    notification = db.query(Notification).filter(
        Notification.id == notification_id,
        Notification.patient_id == patient.id
    ).first()

    if not notification:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Notification not found"
        )

    notification.is_read = True
    db.commit()

    return {"message": "Notification marked as read"}