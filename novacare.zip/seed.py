"""
Database seed script to populate initial data
Run this after starting the application for the first time
"""

import sys
from sqlalchemy.orm import Session
from datetime import datetime, time, timedelta, date
from database.db import SessionLocal, engine
from database.models import (
    User, Patient, Provider, Clinic, ExaminationRoom, MedicalEquipment,
    ServiceType, ProviderAvailability, UserRole, AppointmentPriority, Base
)
from services.auth import get_password_hash


def seed_database():
    """Seed the database with initial data"""

    # Create tables
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()

    try:
        # Check if data already exists
        existing_user = db.query(User).first()
        if existing_user:
            print("Database already seeded. Skipping...")
            return

        print("Seeding database...")

        # Create Users
        users = [
            # Admin
            User(
                user_id="admin001",
                email="admin@novacare.com",
                full_name="System Administrator",
                role=UserRole.ADMIN,
                hashed_password=get_password_hash("admin123"),
                is_active=True
            ),
            # Manager
            User(
                user_id="mgr001",
                email="manager@novacare.com",
                full_name="John Manager",
                role=UserRole.MANAGER,
                hashed_password=get_password_hash("manager123"),
                is_active=True
            ),
            # Providers
            User(
                user_id="dr001",
                email="dr.smith@novacare.com",
                full_name="Dr. Emily Smith",
                role=UserRole.PROVIDER,
                hashed_password=get_password_hash("provider123"),
                is_active=True
            ),
            User(
                user_id="dr002",
                email="dr.johnson@novacare.com",
                full_name="Dr. Michael Johnson",
                role=UserRole.PROVIDER,
                hashed_password=get_password_hash("provider123"),
                is_active=True
            ),
            User(
                user_id="dr003",
                email="dr.williams@novacare.com",
                full_name="Dr. Sarah Williams",
                role=UserRole.PROVIDER,
                hashed_password=get_password_hash("provider123"),
                is_active=True
            ),
            # Patients
            User(
                user_id="pat001",
                email="alice.brown@email.com",
                full_name="Alice Brown",
                role=UserRole.PATIENT,
                hashed_password=get_password_hash("patient123"),
                is_active=True
            ),
            User(
                user_id="pat002",
                email="bob.davis@email.com",
                full_name="Bob Davis",
                role=UserRole.PATIENT,
                hashed_password=get_password_hash("patient123"),
                is_active=True
            ),
            User(
                user_id="pat003",
                email="carol.miller@email.com",
                full_name="Carol Miller",
                role=UserRole.PATIENT,
                hashed_password=get_password_hash("patient123"),
                is_active=True
            ),
        ]

        db.add_all(users)
        db.flush()

        print("✓ Users created")

        # Create Clinics
        clinics = [
            Clinic(
                name="NovaCare Main Clinic",
                address="123 Healthcare Ave, Boston, MA 02101",
                phone_number="617-555-0100",
                email="main@novacare.com",
                operating_hours_start=time(8, 0),
                operating_hours_end=time(18, 0),
                is_active=True
            ),
            Clinic(
                name="NovaCare Specialty Center",
                address="456 Medical Blvd, Cambridge, MA 02138",
                phone_number="617-555-0200",
                email="specialty@novacare.com",
                operating_hours_start=time(9, 0),
                operating_hours_end=time(17, 0),
                is_active=True
            ),
        ]

        db.add_all(clinics)
        db.flush()

        print("✓ Clinics created")

        # Create Examination Rooms
        rooms = [
            ExaminationRoom(clinic_id=1, room_number="101", room_type="standard"),
            ExaminationRoom(clinic_id=1, room_number="102", room_type="standard"),
            ExaminationRoom(clinic_id=1, room_number="103", room_type="procedure"),
            ExaminationRoom(clinic_id=1, room_number="104", room_type="consultation"),
            ExaminationRoom(clinic_id=2, room_number="201", room_type="standard"),
            ExaminationRoom(clinic_id=2, room_number="202", room_type="procedure"),
        ]

        db.add_all(rooms)
        db.flush()

        print("✓ Examination rooms created")

        # Create Medical Equipment
        equipment = [
            MedicalEquipment(
                name="X-Ray Machine A",
                equipment_type="Diagnostic Imaging",
                model_number="XR-2000",
                serial_number="XR2000-001",
                is_available=True
            ),
            MedicalEquipment(
                name="Ultrasound Machine",
                equipment_type="Diagnostic Imaging",
                model_number="US-500",
                serial_number="US500-001",
                is_available=True
            ),
            MedicalEquipment(
                name="ECG Machine",
                equipment_type="Cardiac Monitoring",
                model_number="ECG-300",
                serial_number="ECG300-001",
                is_available=True
            ),
        ]

        db.add_all(equipment)
        db.flush()

        print("✓ Medical equipment created")

        providers = [
            Provider(
                user_id=users[2].id,
                clinic_id=1,
                specialty="General Practice",
                license_number="MA-GP-12345",
                phone_number="617-555-0101"
            ),
            Provider(
                user_id=users[3].id,
                clinic_id=1,
                specialty="Cardiology",
                license_number="MA-CA-23456",
                phone_number="617-555-0102"
            ),
            Provider(
                user_id=users[4].id,
                clinic_id=2,
                specialty="Orthopedics",
                license_number="MA-OR-34567",
                phone_number="617-555-0201"
            ),
        ]

        db.add_all(providers)
        db.flush()

        print("✓ Providers created")

        availabilities = []
        for provider in providers:
            for day in range(5):  # Monday to Friday
                availabilities.append(
                    ProviderAvailability(
                        provider_id=provider.id,
                        day_of_week=day,
                        start_time=time(9, 0),
                        end_time=time(17, 0),
                        is_available=True
                    )
                )

        db.add_all(availabilities)
        db.flush()

        print("✓ Provider availability created")

        patients = [
            Patient(
                user_id=users[5].id,  # Alice
                medical_record_number="MRN-001234",
                phone_number="617-555-1001",
                date_of_birth=date(1985, 3, 15),
                address="789 Patient St, Boston, MA 02115",
                emergency_contact="John Brown - 617-555-1002"
            ),
            Patient(
                user_id=users[6].id,  # Bob
                medical_record_number="MRN-001235",
                phone_number="617-555-1003",
                date_of_birth=date(1978, 7, 22),
                address="321 Health Rd, Cambridge, MA 02139",
                emergency_contact="Jane Davis - 617-555-1004"
            ),
            Patient(
                user_id=users[7].id,  # Carol
                medical_record_number="MRN-001236",
                phone_number="617-555-1005",
                date_of_birth=date(1992, 11, 8),
                address="654 Wellness Ln, Somerville, MA 02143",
                emergency_contact="David Miller - 617-555-1006"
            ),
        ]

        db.add_all(patients)
        db.flush()

        print("✓ Patients created")

        # Create Service Types
        service_types = [
            ServiceType(
                clinic_id=1,
                name="General Consultation",
                description="Standard primary care consultation",
                duration_minutes=30,
                priority_level=AppointmentPriority.MEDIUM
            ),
            ServiceType(
                clinic_id=1,
                name="Annual Physical",
                description="Comprehensive annual health examination",
                duration_minutes=60,
                priority_level=AppointmentPriority.LOW
            ),
            ServiceType(
                clinic_id=1,
                name="Cardiology Consultation",
                description="Specialized cardiac evaluation",
                duration_minutes=45,
                priority_level=AppointmentPriority.HIGH,
                requires_equipment=True
            ),
            ServiceType(
                clinic_id=2,
                name="Orthopedic Evaluation",
                description="Musculoskeletal assessment",
                duration_minutes=45,
                priority_level=AppointmentPriority.MEDIUM
            ),
            ServiceType(
                clinic_id=1,
                name="Urgent Care",
                description="Acute medical needs",
                duration_minutes=20,
                priority_level=AppointmentPriority.URGENT,
                requires_equipment=True
            ),
        ]

        db.add_all(service_types)
        db.flush()

        print("✓ Service types created")

        db.commit()

        print("\n✅ Database seeded successfully!")
        print("\n📋 Test Credentials:")
        print("=" * 50)
        print("Admin:    user_id=admin001    password=admin123")
        print("Manager:  user_id=mgr001      password=manager123")
        print("Provider: user_id=dr001       password=provider123")
        print("Patient:  user_id=pat001      password=patient123")
        print("=" * 50)

    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()