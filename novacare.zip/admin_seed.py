from database.db import SessionLocal
from database.models import User, UserRole
from services.auth import get_password_hash

db = SessionLocal()
if not db.query(User).filter(User.role == UserRole.ADMIN).first():
    admin = User(
        user_id="admin",
        email="admin@system.com",
        full_name="Super Admin",
        hashed_password=get_password_hash("admin123"),
        role=UserRole.ADMIN,
        is_active=True
    )
    db.add(admin)
    db.commit()
    print("Super Admin created: admin / admin123")
else:
    print("Admin already exists")